const functions = require('firebase-functions')
const {dialogflow} = require('actions-on-google')

const WELCOME_INTENT = 'Default Welcome Intent'
const FALLBACK_INTENT = 'Default Fallback Intent'

const ADD_OPT = 'add_code_opt'
const ADD_OPT_GET = 'add_code_opt_get'
const RUN = 'run'
const ADD_CODE = 'add_code'
const ADD_FOR = 'add_for'
const ADD_FOR_INDEX = 'add_for_index'
const INTEGER_VALUE = 'integer_value'
const STRING_VALUE = 'string_value'
const ADD_VAR_STRING = 'add_var_string'
const ADD_VAR_INTEGER = 'add_var_integer'
const ADD_FOR_OP = 'add_for_op'
//const VAR_TYPE = 'variable_type'
const NUMBER = 'number'
const TYPE = ['string','int']

var variable
var operation


const app = dialogflow()

function find(name) {
    var i;
    for (i = 0; i < variable.length / 3; i++) {
        if (variable[3*i + 1] == name) {
            return 3*i+2
        }
    }
    
    return null
}

function findType(name) {
    var i;
    for (i = 0; i < TYPE.length; i++) {
        if (TYPE[i] == name) {
            return i
        }
    }
    return null
}

app.intent(RUN, (conv) =>{
    const number = operation.length / 6;
    var i;
    var str = "Now start running your code!";
    for (i = 0; i < number; i++) {
        if(operation[i*6] == "for") {
            const times = operation[i*6 + 1];
            var j;
            for(j = 0; j < times; j++) {
                if(operation[6*i + 2] == "print") {
                    const index = find(operation[6*i + 3]);
                    str += ("After " + j +" loops, " + operation[6*i + 3] + " is " + variable[index])
                }
                
                if(operation[6*i + 2] == "add") {
                    const index = find(operation[6*i + 3]);
                    const num = operation[6*i + 4]
                    variable[index] = parseInt(variable[index]) + parseInt(num)
                }
                
                if(operation[6*i + 2] == "substract") {
                    const index = find(operation[6*i + 3]);
                    const num = operation[6*i + 4]
                    variable[index] = parseInt(variable[index]) - parseInt(num) 
                }
                
                
            }
        }
    }
    conv.close(str)
    
})

app.intent(WELCOME_INTENT, (conv) =>{
    variable = []
    operation = []
    conv.ask("Welcome to the voicoder! Ask for the code!")
    conv.ask("To add a new line, please say: add a new line.\nTo run the code, please say: run.")
})

app.intent(FALLBACK_INTENT, (conv) =>{
    conv.ask("Sorry, I cannot understand that!\n")
    conv.ask("To add a new line, please say: add a new line.\nTo run the code, please say: run.")
})


app.intent(ADD_CODE, (conv) =>{
    conv.ask("What kind of code would you like to add? Please select from variable with name and type, operation, and loop.")

})

app.intent(ADD_FOR, (conv) => {
    conv.ask("How many times do you want to loop?");
    operation.push("for")
})

app.intent(ADD_FOR_INDEX, (conv) =>{
    const index = conv.parameters[NUMBER];
    conv.ask("What is your operation inside?")
    operation.push(index)
})

app.intent(ADD_OPT, (conv) => {
    conv.ask("What kind of operation do you like? Please select from print, add, and substract.")
})


app.intent(ADD_OPT_GET, (conv, {OPERATION,PARA1,PARA2}) => {
    
    if(OPERATION == "print") {
        const index1 = find(PARA1);
        if (index1 == null) {
            conv.ask("This " + PARA1 + " is not initialized.")
        }
        else {
            operation.push("for")
            operation.push(1)
            operation.push(OPERATION)
            operation.push(PARA1)
            operation.push(PARA2)
            operation.push("\0")
            const index = operation.length - 2;
            conv.ask("The " + operation[index - 1] + " is printed.")
            
        }
    }
    else {
        const index1 = find(PARA1); 
        if (index1 == null) {
            conv.ask("This " + PARA1 + " is not initialized.")
        }
        else {
            operation.push("for")
            operation.push(1)
            operation.push(OPERATION)
            operation.push(PARA1)
            operation.push(PARA2)
            operation.push("\0")
            const index = operation.length - 2;
            conv.ask(operation[index - 2] + " " + operation[index - 1] + " by " + operation[index])
        }
    }
})
    



app.intent(ADD_FOR_OP, (conv, {OPERATION,PARA1,PARA2}) => {
    
    if(OPERATION == "print") {
        const index1 = find(PARA1);
        if (index1 == null) {
            conv.ask("This " + PARA1 + " is not initialized.")
        }
        else {
            operation.push(OPERATION)
            operation.push(PARA1)
            operation.push(PARA2)
            operation.push("\0")
            const index = operation.length - 2;
            conv.ask("The new " + operation[index - 4] + "loop with " + operation[index - 3] + "times is initialized.")
            conv.ask("The " + operation[index - 1] + " is printed.")
            
        }
    }
    else {
        const index1 = find(PARA1); 
        if (index1 == null) {
            conv.ask("This " + PARA1 + " is not initialized.")
        }
        else {
            operation.push(OPERATION)
            operation.push(PARA1)
            operation.push(PARA2)
            operation.push("\0")
            const index = operation.length - 2;
            conv.ask("The new " + operation[index - 4] + "loop with " + operation[index - 3] + "times is initialized.")
            conv.ask(operation[index - 2] + " " + operation[index - 1] + " by " + operation[index])
        }
    }
    
    
})

app.intent(STRING_VALUE, (conv, {variable_type, var_name}) =>{

    if (variable_type == null) {
        conv.ask("Invalid data type!")
    }
    else if(findType(variable_type) == null){
        conv.ask("Invalide data type!")
    }
    else {
        variable.push(variable_type);
        variable.push(var_name);
        conv.ask("what value do you want to put into the variable?")
    }

    //conv.ask("What value do you want to put into variable? Please say the word in the following order. Name, Type, Value")
})

app.intent(INTEGER_VALUE, (conv, {variable_type, var_name}) =>{

    if (variable_type == null) {
        conv.ask("Invalid data type!")
    }
    else if(findType(variable_type) == null){
        conv.ask("Invalide data type!")
    }
    else {
        variable.push(variable_type);
        variable.push(var_name);
        conv.ask("what value do you want to put into the variable?")
    }

    //conv.ask("What value do you want to put into variable? Please say the word in the following order. Name, Type, Value")
})

app.intent(ADD_VAR_STRING, (conv,  {VALUE}) => {
    if ((variable.length%3) != 2) {
        conv.ask("Invalid input!" + variable.length)
    }
    else {
        variable.push(VALUE);
        const index = variable.length - 1;
        conv.ask("The new " + variable[index - 2] + " " + variable[index - 1] + " is successfully initialized as " + variable[index])
    }
})

app.intent(ADD_VAR_INTEGER, (conv, {VALUE}) => {
    if ((variable.length%3) != 2) {
        conv.ask("Invalid input!" + variable.length)
    }
    else {
        variable.push(VALUE);
        const index = variable.length - 1;
        conv.ask("The new " + variable[index - 2] + " " + variable[index - 1] + " is successfully initialized as " + variable[index])
    }
})


exports.dialogflowFirebaseFulfillment = functions.https.onRequest(app)